function usageColor(percent) {
  if (percent >= 90) return "#d64545";
  if (percent >= 70) return "#b45309";
  return "#1c7c3f";
}

function renderUsageBar(label, percent, detailText) {
  const color = usageColor(percent);
  return `
    <div style="margin-bottom:10px;">
      <div style="display:flex; justify-content:space-between; font-size:12px; margin-bottom:3px;">
        <span>${escapeHtml(label)}</span>
        <span style="color:${color}; font-weight:600;">${percent}%${detailText ? " ・ " + escapeHtml(detailText) : ""}</span>
      </div>
      <div style="background:#e5e7eb; border-radius:4px; height:8px; overflow:hidden;">
        <div style="background:${color}; height:100%; width:${Math.min(percent, 100)}%;"></div>
      </div>
    </div>
  `;
}

async function loadSystemStatus() {
  const container = document.getElementById("system-status-container");
  const res = await apiFetch("/api/sysstatus/system");
  if (!res.ok) {
    container.innerHTML = `<p style="color:#d64545;">載入失敗: ${escapeHtml((res.data && res.data.message) || "未知錯誤")}</p>`;
    return;
  }
  const d = res.data.data;

  let cpuHtml = "";
  d.cpu.forEach((c) => {
    const label = c.core === "cpu" ? "CPU(全部核心平均)" : `核心 ${c.core.replace("cpu", "")}`;
    cpuHtml += renderUsageBar(label, c.percent, "");
  });

  container.innerHTML = `
    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:24px;">
      <div>
        <table class="kv-table">
          <tr><td class="k">目前時間</td><td>${escapeHtml(d.current_time)}</td></tr>
          <tr><td class="k">作業系統</td><td>${escapeHtml(d.os_info.os_name)}</td></tr>
          <tr><td class="k">核心版本</td><td style="font-family:var(--mono); font-size:12px;">${escapeHtml(d.os_info.kernel_version)}</td></tr>
        </table>
        ${renderUsageBar("記憶體", d.memory.percent, `${d.memory.used_mb} / ${d.memory.total_mb} MB`)}
        ${renderUsageBar("磁碟空間 (/)", d.disk.percent, `${d.disk.used_gb} / ${d.disk.total_gb} GB`)}
      </div>
      <div>
        <div style="font-size:12px; color:#6b7280; margin-bottom:8px;">CPU 使用率</div>
        ${cpuHtml}
      </div>
    </div>
  `;
}

// ---------------------------------------------------------------------------
// Docker
// ---------------------------------------------------------------------------
async function loadDockerStatus() {
  const tbody = document.getElementById("docker-tbody");
  const res = await apiFetch("/api/sysstatus/docker");
  if (!res.ok) {
    tbody.innerHTML = `<tr><td colspan="7" style="color:#d64545;">載入失敗: ${escapeHtml((res.data && res.data.message) || "未知錯誤")}</td></tr>`;
    return;
  }
  tbody.innerHTML = "";
  if (res.data.data.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7">沒有監控中的容器(請檢查設定檔的 sysstatus.docker_containers 清單)</td></tr>`;
    return;
  }
  res.data.data.forEach((c) => {
    const tr = document.createElement("tr");
    const stateColor = c.state === "running" ? "#1c7c3f" : "#d64545";
    tr.innerHTML = `
      <td style="font-family:var(--mono); font-size:12px;">${escapeHtml(c.name)}</td>
      <td style="font-size:12px; color:#6b7280;">${escapeHtml(c.purpose)}</td>
      <td style="font-size:12px;">${escapeHtml(c.image)}</td>
      <td><span style="color:${stateColor};">${escapeHtml(c.status)}</span></td>
      <td style="font-size:12px;">${escapeHtml(c.ports || "-")}</td>
      <td style="font-size:12px;">${escapeHtml(c.created)}</td>
      <td>
        <button class="secondary docker-log-btn" type="button" data-name="${escapeHtml(c.name)}" style="font-size:11px;">Log</button>
        <button class="secondary restart-btn-pink docker-restart-btn" type="button" data-name="${escapeHtml(c.name)}" style="font-size:11px;">重啟</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

async function showDockerLog(name) {
  openLogViewer(`Docker Log - ${name}`, `/api/sysstatus/docker/logs/${encodeURIComponent(name)}`);
}

async function restartDockerContainer(name) {
  if (!confirm(`確定要重啟容器「${name}」嗎?這會短暫中斷這個容器提供的服務。`)) return;
  const res = await apiFetchJSON("/api/sysstatus/docker/restart", "POST", { container_name: name });
  if (res.ok) {
    alert(res.data.message);
    loadDockerStatus();
  } else {
    alert("重啟失敗: " + ((res.data && res.data.message) || "未知錯誤"));
  }
}

// ---------------------------------------------------------------------------
// systemd
// ---------------------------------------------------------------------------
async function loadSystemdStatus() {
  const tbody = document.getElementById("systemd-tbody");
  const res = await apiFetch("/api/sysstatus/systemd");
  if (!res.ok) {
    tbody.innerHTML = `<tr><td colspan="7" style="color:#d64545;">載入失敗: ${escapeHtml((res.data && res.data.message) || "未知錯誤")}</td></tr>`;
    return;
  }
  tbody.innerHTML = "";
  res.data.data.forEach((s) => {
    const tr = document.createElement("tr");
    const isActive = s.active_state === "active";
    const stateColor = isActive ? "#1c7c3f" : "#d64545";
    tr.innerHTML = `
      <td style="font-family:var(--mono); font-size:12px;">${escapeHtml(s.service)}</td>
      <td style="font-size:12px; color:#6b7280;">${escapeHtml(s.purpose)}</td>
      <td><span style="color:${stateColor};">${escapeHtml(s.active_state)}${s.sub_state ? " (" + escapeHtml(s.sub_state) + ")" : ""}</span></td>
      <td style="font-size:12px;">${escapeHtml(s.port || "-")}</td>
      <td style="font-size:12px;">${escapeHtml(s.active_since || "-")}</td>
      <td style="font-size:12px;">${escapeHtml(s.main_pid || "-")}</td>
      <td>
        <button class="secondary systemd-log-btn" type="button" data-name="${escapeHtml(s.service)}" style="font-size:11px;">Log</button>
        <button class="secondary restart-btn-pink systemd-restart-btn" type="button" data-name="${escapeHtml(s.service)}" style="font-size:11px;">重啟</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

async function showSystemdLog(name) {
  openLogViewer(`Journal Log - ${name}`, `/api/sysstatus/systemd/logs/${encodeURIComponent(name)}`);
}

async function restartSystemdService(name) {
  let warning = `確定要重啟服務「${name}」嗎?這會短暫中斷這個服務。`;
  if (name === "nanomdm-webui.service") {
    warning = `⚠️ 這是目前正在提供這個管理介面本身的服務!重啟後這個網頁會立刻斷線,需要等服務重新啟動完成後重新整理頁面才能繼續使用。\n\n確定要繼續嗎?`;
  }
  if (!confirm(warning)) return;
  const res = await apiFetchJSON("/api/sysstatus/systemd/restart", "POST", { service_name: name });
  if (res.ok) {
    alert(res.data.message);
    loadSystemdStatus();
  } else {
    alert("重啟失敗: " + ((res.data && res.data.message) || "未知錯誤"));
  }
}

// ---------------------------------------------------------------------------
// MySQL
// ---------------------------------------------------------------------------
async function loadMysqlStatus(exact) {
  const container = document.getElementById("mysql-status-container");
  container.innerHTML = exact ? "精確計算中,資料表較多時可能需要幾秒..." : "載入中...";
  const url = exact ? "/api/sysstatus/mysql?exact=1" : "/api/sysstatus/mysql";
  const res = await apiFetch(url);
  if (!res.ok) {
    container.innerHTML = `<p style="color:#d64545;">載入失敗: ${escapeHtml((res.data && res.data.message) || "未知錯誤")}</p>`;
    return;
  }
  if (res.data.data.length === 0) {
    container.innerHTML = `<p style="color:#9ca3af;">沒有查到任何資料庫</p>`;
    return;
  }
  const rowsLabel = exact ? "精確筆數" : "估計筆數";
  let html = "";
  if (exact) {
    html += `
      <p style="font-size:12px; color:#166534; background:#f0fdf4; border:1px solid #bbf7d0; border-radius:6px; padding:8px 12px; margin-bottom:10px;">
        ✅ 以下是即時精確查詢結果(真正的 COUNT(*)),不是估計值。
      </p>
    `;
  } else {
    html += `
      <p style="font-size:12px; color:#6b7280; margin-bottom:10px;">
        「估計筆數」來自 MySQL 內部統計資訊,不是即時精確查詢(這樣載入速度才夠快)。
        執行大量刪除(例如指令歷史清理)後,這個估計值不會立刻更新,可能要過一段時間才會反映最新狀態,
        這不代表刪除沒有生效。如果想立刻看到精確數字,可以按上方「重新整理(精確筆數)」按鈕。
      </p>
    `;
  }
  if (res.data.errors && res.data.errors.length > 0) {
    html += `<div style="background:#fef3c7; border:1px solid #fde68a; border-radius:6px; padding:8px 12px; margin-bottom:12px; font-size:12px;">
      ⚠️ 部分資料庫查詢失敗(可能是 .env 裡的密碼設定還沒對應到,或帳號權限不足):<br>
      ${res.data.errors.map((e) => escapeHtml(e)).join("<br>")}
    </div>`;
  }
  res.data.data.forEach((db) => {
    html += `
      <div style="margin-bottom:16px;">
        <h3 style="margin-bottom:6px;">${escapeHtml(db.database)} <span style="color:#9ca3af; font-size:12px; font-weight:normal;">(共 ${db.total_rows.toLocaleString()} 筆資料)</span></h3>
        <table class="data-table">
          <thead><tr><th>資料表</th><th>用途</th><th>${rowsLabel}</th><th>大小 (MB)</th></tr></thead>
          <tbody>
            ${db.tables.map((t) => `<tr><td style="font-family:var(--mono); font-size:12px;">${escapeHtml(t.table)}</td><td style="font-size:12px; color:#6b7280;">${escapeHtml(t.purpose)}</td><td>${t.rows.toLocaleString()}</td><td>${t.size_mb}</td></tr>`).join("")}
          </tbody>
        </table>
      </div>
    `;
  });
  container.innerHTML = html;
}

// ---------------------------------------------------------------------------
// Log 檢視 Modal (docker/systemd共用)
// ---------------------------------------------------------------------------
async function openLogViewer(title, apiPath) {
  document.getElementById("log-viewer-title").textContent = title;
  document.getElementById("log-viewer-content").textContent = "載入中...";
  openModal("log-viewer-modal");

  const res = await apiFetch(apiPath);
  const contentEl = document.getElementById("log-viewer-content");
  if (res.ok) {
    contentEl.textContent = res.data.logs || "(沒有log內容)";
    contentEl.scrollTop = contentEl.scrollHeight;
  } else {
    contentEl.textContent = "載入失敗: " + ((res.data && res.data.message) || "未知錯誤");
  }
}

// ---------------------------------------------------------------------------
// 靜態檔案檢視
// ---------------------------------------------------------------------------
function renderFileExistBadge(item) {
  if (item.exists) {
    const detail = item.size_bytes !== undefined ? ` (${item.size_bytes} bytes, ${escapeHtml(item.modified_at)})` : "";
    return `<span style="color:#1c7c3f;">✅ 存在</span><span style="color:#9ca3af; font-size:11px;">${detail}</span>`;
  }
  return `<span style="color:#d64545; font-weight:600;">❌ 不存在</span>`;
}

function renderFileTable(title, items) {
  if (items.length === 0) return "";
  return `
    <h3 style="margin-top:16px; margin-bottom:6px; font-size:14px;">${escapeHtml(title)}</h3>
    <table class="data-table">
      <thead><tr><th style="width:35%;">路徑</th><th style="width:40%;">說明</th><th>狀態</th></tr></thead>
      <tbody>
        ${items.map((item) => `
          <tr>
            <td style="font-family:var(--mono); font-size:11px; word-break:break-all;">${escapeHtml(item.path)}</td>
            <td style="font-size:12px; color:#6b7280;">${escapeHtml(item.description)}</td>
            <td style="font-size:12px;">${renderFileExistBadge(item)}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

async function loadStaticFilesStatus() {
  const container = document.getElementById("static-files-container");
  container.innerHTML = "載入中...";
  const res = await apiFetch("/api/sysstatus/static-files");
  if (!res.ok) {
    container.innerHTML = `<p style="color:#d64545;">載入失敗: ${escapeHtml((res.data && res.data.message) || "未知錯誤")}</p>`;
    return;
  }
  const d = res.data.data;

  let html = "";
  html += renderFileTable("1. Script 檔案", d.scripts);
  html += renderFileTable("2. CSV 檔案", d.csv_files);
  html += renderFileTable("3. JSON 註冊檔案(群組專屬 enroll json)", d.json_files.enroll_profiles);
  html += renderFileTable("其他固定的 JSON 檔案", d.json_files.fixed);
  html += renderFileTable("4. mobileconfig 描述檔案", d.mobileconfig_files);
  html += renderFileTable("5. .env 檔案", [d.env_file]);

  if (d.unaccounted_files && d.unaccounted_files.length > 0) {
    html += `
      <details style="background:#fef3c7; border:1px solid #fde68a; border-radius:6px; padding:10px 14px; margin-top:16px; font-size:12px;">
        <summary style="cursor:pointer; font-weight:600;">⚠️ 部署目錄中其他檔案(${d.unaccounted_files.length} 個)</summary>
        <div style="margin-top:8px;">
          ${d.unaccounted_files.map((f) => `<span style="font-family:var(--mono);">${escapeHtml(f)}</span>`).join("<br>")}
        </div>
      </details>
    `;
  } else {
    html += `<p style="color:#9ca3af; font-size:12px; margin-top:12px;">✅ 部署目錄裡沒有發現未列入清單的檔案</p>`;
  }

  container.innerHTML = html;
}

let shPermissionsMissingPaths = [];

async function scanShPermissions() {
  const resultContainer = document.getElementById("sh-permissions-result");
  const tbody = document.getElementById("sh-permissions-tbody");
  const summary = document.getElementById("sh-permissions-summary");
  const grantBtn = document.getElementById("sh-permissions-grant-btn");
  const scanBtn = document.getElementById("sh-permissions-scan-btn");

  scanBtn.disabled = true;
  scanBtn.textContent = "掃描中...";

  const res = await apiFetch("/api/sysstatus/sh-permissions/scan");

  scanBtn.disabled = false;
  scanBtn.textContent = "掃描 .sh 檔案權限";

  if (!res.ok) {
    alert("掃描失敗: " + ((res.data && res.data.message) || "未知錯誤"));
    return;
  }

  const files = res.data.files;
  shPermissionsMissingPaths = files.filter((f) => !f.is_executable).map((f) => f.path);

  resultContainer.style.display = "";
  summary.textContent = `共掃描到 ${res.data.total_count} 個 .sh 檔案,其中 ${res.data.no_exec_count} 個缺少執行權限。`;

  tbody.innerHTML = files
    .map((f) => {
      const statusBadge = f.is_executable
        ? `<span class="badge ok">正常</span>`
        : `<span class="badge warn">缺少執行權限</span>`;
      return `<tr>
        <td style="font-family: var(--mono); font-size:12px; word-break:break-all;">${escapeHtml(f.path)}</td>
        <td style="font-family: var(--mono);">${escapeHtml(f.mode)}</td>
        <td>${statusBadge}</td>
      </tr>`;
    })
    .join("");

  grantBtn.style.display = shPermissionsMissingPaths.length > 0 ? "" : "none";
  grantBtn.textContent = `賦予執行權限(僅缺少的部分,共 ${shPermissionsMissingPaths.length} 個)`;
}

async function grantShPermissions() {
  if (shPermissionsMissingPaths.length === 0) return;
  if (!confirm(`確定要對這 ${shPermissionsMissingPaths.length} 個缺少執行權限的 .sh 檔案,補上執行權限嗎?`)) return;

  const res = await apiFetchJSON("/api/sysstatus/sh-permissions/grant", "POST", { paths: shPermissionsMissingPaths });
  if (res.ok) {
    alert(`已完成:成功 ${res.data.success_count} 個` + (res.data.failed_paths.length > 0 ? `,失敗 ${res.data.failed_paths.length} 個: ${res.data.failed_paths.join(", ")}` : ""));
    scanShPermissions(); // 重新掃描,讓畫面反映最新狀態
  } else {
    alert("授權失敗: " + ((res.data && res.data.message) || "未知錯誤"));
  }
}

function restartAllServices() {
  if (!confirm("確定要重啟所有服務嗎?這會依序重啟所有 Docker 容器與 systemd 服務,短暫中斷所有服務的運作,包含這個管理介面本身。")) return;

  const btn = document.getElementById("restart-all-btn");
  const container = document.getElementById("restart-all-progress");
  btn.disabled = true;
  container.innerHTML = "";

  const categoryLabel = { docker: "Docker容器", systemd: "systemd服務" };
  const statusRows = {};
  const es = new EventSource(apiUrl("/api/sysstatus/restart-all-stream"));

  es.onmessage = (event) => {
    let update;
    try {
      update = JSON.parse(event.data);
    } catch (e) {
      return;
    }

    if (update.done !== undefined && update.category === undefined) {
      const finalDiv = document.createElement("div");
      finalDiv.style.cssText = `margin-top:8px; font-weight:600; color:${update.overall_ok ? "#1c7c3f" : "#b45309"};`;
      finalDiv.textContent = update.overall_ok
        ? "✅ 所有服務都已經重啟完成"
        : "⚠️ 重啟流程已經跑完,但有部分服務失敗,請往上檢查每一項的結果";
      container.appendChild(finalDiv);
      btn.disabled = false;
      es.close();
      // 重啟nanomdm-webui.service之後,這個頁面本身也會短暫斷線,稍微延遲一下再重新整理
      // 兩個狀態表格,給服務一點時間完全啟動完成
      setTimeout(() => {
        loadDockerStatus();
        loadSystemdStatus();
      }, 3000);
      return;
    }

    const rowKey = `${update.category}-${update.name}`;
    let row = statusRows[rowKey];
    if (!row) {
      row = document.createElement("div");
      row.style.cssText = "border:1px solid var(--border-color); border-radius:6px; padding:8px 12px; margin-top:6px; font-size:13px;";
      container.appendChild(row);
      statusRows[rowKey] = row;
    }
    const iconMap = { running: "⏳", done: "✅", error: "❌" };
    const icon = iconMap[update.status] || "•";
    const msgText = update.message ? `: ${escapeHtml(update.message)}` : "";
    row.innerHTML = `${icon} [${categoryLabel[update.category] || update.category}] ${escapeHtml(update.name)}${msgText}`;
  };

  es.onerror = () => {
    // nanomdm-webui.service重啟後,連線中斷是預期中的行為(服務本身正在重啟),
    // 不當作錯誤處理,只是把按鈕解鎖、稍後重新整理狀態表格
    btn.disabled = false;
    es.close();
    setTimeout(() => {
      loadDockerStatus();
      loadSystemdStatus();
    }, 3000);
  };
}

document.addEventListener("DOMContentLoaded", () => {
  loadSystemStatus();
  loadDockerStatus();
  loadSystemdStatus();
  loadMysqlStatus(false);
  loadStaticFilesStatus();
  loadCleanupSettings();

  document.getElementById("refresh-system-btn").addEventListener("click", loadSystemStatus);
  document.getElementById("restart-all-btn").addEventListener("click", restartAllServices);
  document.getElementById("refresh-mysql-btn").addEventListener("click", () => loadMysqlStatus(false));
  document.getElementById("refresh-mysql-exact-btn").addEventListener("click", () => loadMysqlStatus(true));
  document.getElementById("refresh-static-files-btn").addEventListener("click", loadStaticFilesStatus);
  document.getElementById("cleanup-save-settings-btn").addEventListener("click", saveCleanupSettings);
  document.getElementById("cleanup-preview-btn").addEventListener("click", previewCleanup);
  document.getElementById("cleanup-execute-btn").addEventListener("click", executeCleanup);
  document.getElementById("sh-permissions-scan-btn").addEventListener("click", scanShPermissions);
  document.getElementById("sh-permissions-grant-btn").addEventListener("click", grantShPermissions);

  document.getElementById("docker-tbody").addEventListener("click", (e) => {
    const name = e.target.dataset.name;
    if (!name) return;
    if (e.target.classList.contains("docker-log-btn")) showDockerLog(name);
    else if (e.target.classList.contains("docker-restart-btn")) restartDockerContainer(name);
  });

  document.getElementById("systemd-tbody").addEventListener("click", (e) => {
    const name = e.target.dataset.name;
    if (!name) return;
    if (e.target.classList.contains("systemd-log-btn")) showSystemdLog(name);
    else if (e.target.classList.contains("systemd-restart-btn")) restartSystemdService(name);
  });

  // 系統資源每10秒自動更新一次(輕量,不影響Docker/systemd/MySQL的手動重新整理)
  setInterval(loadSystemStatus, 10000);
});

// ---------------------------------------------------------------------------
// nanomdm 指令歷史清理
// ---------------------------------------------------------------------------
async function loadCleanupSettings() {
  const res = await apiFetch("/api/cleanup/settings");
  if (!res.ok) return;
  document.getElementById("cleanup-retention-days-input").value = res.data.settings.retention_days;
  document.getElementById("cleanup-auto-enabled-input").checked = res.data.settings.auto_enabled;
}

async function saveCleanupSettings() {
  const retentionDays = parseInt(document.getElementById("cleanup-retention-days-input").value, 10);
  const autoEnabled = document.getElementById("cleanup-auto-enabled-input").checked;

  if (!retentionDays || retentionDays < 1) {
    alert("保留天數必須是大於0的整數");
    return;
  }

  const res = await apiFetchJSON("/api/cleanup/settings", "POST", {
    retention_days: retentionDays, auto_enabled: autoEnabled,
  });
  if (res.ok) {
    alert("設定已儲存");
  } else {
    alert("儲存失敗: " + ((res.data && res.data.message) || "未知錯誤"));
  }
}

async function previewCleanup() {
  const retentionDays = parseInt(document.getElementById("cleanup-retention-days-input").value, 10);
  if (!retentionDays || retentionDays < 1) {
    alert("保留天數必須是大於0的整數");
    return;
  }

  const btn = document.getElementById("cleanup-preview-btn");
  btn.disabled = true;
  btn.textContent = "查詢中...";

  const res = await apiFetch(`/api/cleanup/preview?retention_days=${retentionDays}`);

  btn.disabled = false;
  btn.textContent = "預覽清理範圍";

  if (!res.ok) {
    alert("預覽失敗: " + ((res.data && res.data.message) || "未知錯誤"));
    return;
  }

  const data = res.data;
  document.getElementById("cleanup-preview-commands-count").textContent = data.commands_count;
  document.getElementById("cleanup-preview-results-count").textContent =
    data.command_results_count !== null ? data.command_results_count : "未知";
  document.getElementById("cleanup-preview-queue-count").textContent =
    data.enrollment_queue_count !== null ? data.enrollment_queue_count : "未知";

  const breakdownEl = document.getElementById("cleanup-preview-breakdown");
  if (data.by_request_type && data.by_request_type.length > 0) {
    breakdownEl.innerHTML = "<strong>依指令類型分類：</strong><br>" +
      data.by_request_type.map(item => `${escapeHtml(item.request_type)}: ${item.count} 筆`).join("　");
  } else {
    breakdownEl.innerHTML = "";
  }

  document.getElementById("cleanup-preview-result").style.display = "";

  if (data.commands_count === 0) {
    alert("目前沒有符合條件、可以安全清除的指令紀錄");
  }
}

async function executeCleanup() {
  const retentionDays = parseInt(document.getElementById("cleanup-retention-days-input").value, 10);
  const previewCount = document.getElementById("cleanup-preview-commands-count").textContent;

  if (!confirm(`確定要清除這 ${previewCount} 筆指令紀錄嗎?此操作無法復原(不會影響裝置目前排隊等待中的指令)。`)) {
    return;
  }

  const password = prompt("請輸入您目前登入的密碼以確認執行清理:");
  if (!password) return;

  const btn = document.getElementById("cleanup-execute-btn");
  btn.disabled = true;
  btn.textContent = "執行中...";

  const res = await apiFetchJSON("/api/cleanup/execute", "POST", {
    retention_days: retentionDays, password,
  });

  btn.disabled = false;
  btn.textContent = "確認執行清理";

  if (res.ok) {
    alert(res.data.message);
    document.getElementById("cleanup-preview-result").style.display = "none";
  } else {
    alert("清理失敗: " + ((res.data && res.data.message) || "未知錯誤"));
  }
}
