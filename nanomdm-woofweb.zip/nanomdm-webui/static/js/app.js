// ---- 共用欄位渲染 (供 profiles.js / dep_profiles.js 等 schema 驅動的表單頁面共用) ----
function renderFieldHelp(field) {
  return field.help
    ? `<p style="color:#6b7280; font-size:11px; margin:2px 0 6px 0; line-height:1.5;">${escapeHtml(field.help)}</p>`
    : "";
}

function renderField(field, value) {
  const val = value !== undefined && value !== null ? value : field.default;
  if (field.type === "checkbox") {
    return `
      <label style="display:flex; align-items:center; gap:8px; font-size:13px; padding:4px 0;">
        <input type="checkbox" data-field="${escapeHtml(field.name)}" ${val ? "checked" : ""}>
        ${escapeHtml(field.label)}
      </label>
      ${renderFieldHelp(field)}
    `;
  }
  if (field.type === "app_checklist") {
    const selected = new Set(Array.isArray(val) ? val : []);
    const optionsHtml = field.options.map((opt) => `
      <label style="display:flex; align-items:center; gap:8px; font-size:13px; padding:4px 0;">
        <input type="checkbox" data-field="${escapeHtml(field.name)}" data-value="${escapeHtml(opt.bundle_id)}" ${selected.has(opt.bundle_id) ? "checked" : ""}>
        ${escapeHtml(opt.label)}
      </label>
    `).join("");
    return `
      <div style="margin:6px 0;">
        <p style="font-size:13px; font-weight:600; margin-bottom:4px;">${escapeHtml(field.label)}</p>
        ${renderFieldHelp(field)}
        <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(140px, 1fr)); gap:2px 10px; margin-top:4px;">
          ${optionsHtml}
        </div>
      </div>
    `;
  }
  if (field.type === "image_upload") {
    const hasExisting = !!val;
    const previewSrc = hasExisting ? `data:image/png;base64,${val}` : "";
    return `
      <div style="margin:6px 0;">
        <p style="font-size:13px; font-weight:600; margin-bottom:4px;">${escapeHtml(field.label)}</p>
        ${renderFieldHelp(field)}
        <input type="hidden" data-field="${escapeHtml(field.name)}" value="${escapeHtml(val || "")}">
        <div style="display:flex; align-items:center; gap:10px; margin-top:6px;">
          <div class="image-upload-preview" style="width:48px; height:48px; border:1px solid var(--border-color); border-radius:8px; overflow:hidden; display:flex; align-items:center; justify-content:center; background:#f9fafb; flex-shrink:0;">
            ${previewSrc ? `<img src="${previewSrc}" style="width:100%; height:100%; object-fit:cover;">` : `<span style="font-size:11px; color:#9ca3af;">無圖示</span>`}
          </div>
          <input type="file" accept="image/png,image/jpeg" class="image-upload-picker" data-target-field="${escapeHtml(field.name)}" style="font-size:12px;">
          ${hasExisting ? `<button type="button" class="secondary image-upload-clear-btn" data-target-field="${escapeHtml(field.name)}" style="font-size:12px;">清除圖示</button>` : ""}
        </div>
      </div>
    `;
  }
  if (field.type === "select") {
    const options = field.options.map((opt) =>
      `<option value="${escapeHtml(opt)}" ${opt === val ? "selected" : ""}>${escapeHtml(opt)}</option>`
    ).join("");
    return `
      <div class="field-row">
        <label>${escapeHtml(field.label)}</label>
        <select data-field="${escapeHtml(field.name)}" style="width:100%;">${options}</select>
      </div>
      ${renderFieldHelp(field)}
    `;
  }
  // text
  return `
    <div class="field-row">
      <label>${escapeHtml(field.label)}</label>
      <input type="text" data-field="${escapeHtml(field.name)}" value="${escapeHtml(val || "")}">
    </div>
    ${renderFieldHelp(field)}
  `;
}

function readFieldValue(container, field) {
  if (field.type === "app_checklist") {
    const checkboxes = container.querySelectorAll(`[data-field="${field.name}"]`);
    return [...checkboxes].filter((cb) => cb.checked).map((cb) => cb.dataset.value);
  }
  const el = container.querySelector(`[data-field="${field.name}"]`);
  if (!el) return field.default;
  if (field.type === "checkbox") return el.checked;
  return el.value;
}

// ---- Debug 面板 ----
const DEBUG_VISIBLE_KEY = "nanomdm_webui_debug_visible";

function initDebugPanel() {
  const body = document.getElementById("debugbar-body");
  const checkbox = document.getElementById("debug-toggle");
  const clearBtn = document.getElementById("clear-debug-btn");

  const saved = localStorage.getItem(DEBUG_VISIBLE_KEY);
  const visible = saved === null ? true : saved === "1";
  checkbox.checked = visible;
  body.classList.toggle("hidden", !visible);

  checkbox.addEventListener("change", () => {
    body.classList.toggle("hidden", !checkbox.checked);
    localStorage.setItem(DEBUG_VISIBLE_KEY, checkbox.checked ? "1" : "0");
  });

  clearBtn.addEventListener("click", () => {
    body.innerHTML = "";
  });
}

function debugLog(label, data, isError) {
  const body = document.getElementById("debugbar-body");
  if (!body) return;
  const entry = document.createElement("div");
  entry.className = "log-entry" + (isError ? " err" : "");
  const ts = new Date().toLocaleTimeString("zh-TW", { hour12: false });
  let dataStr;
  try {
    dataStr = typeof data === "string" ? data : JSON.stringify(data, null, 2);
  } catch (e) {
    dataStr = String(data);
  }
  entry.innerHTML = `<span class="ts">[${ts}]</span><strong>${escapeHtml(label)}</strong>\n${escapeHtml(dataStr)}`;
  body.appendChild(entry);
  body.scrollTop = body.scrollHeight;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ---- 路徑前綴輔助函式 (部署在 nginx 子路徑,例如 /miniweb,後面時需要) ----
function apiUrl(path) {
  const root = window.APP_ROOT || "";
  if (!path.startsWith("/")) return path; // 已經是相對路徑或完整網址,不用處理
  return root + path;
}

// ---- fetch 包裝,自動記錄到 debug 面板,並自動套用路徑前綴 ----
async function apiFetch(url, options) {
  const fullUrl = apiUrl(url);
  options = options || {};
  debugLog(`REQUEST ${options.method || "GET"} ${url}`, options.body || "");
  try {
    const resp = await fetch(fullUrl, options);
    let data;
    const contentType = resp.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      data = await resp.json();
    } else {
      data = await resp.text();
    }
    debugLog(`RESPONSE ${resp.status} ${url}`, data, !resp.ok);
    return { ok: resp.ok, status: resp.status, data };
  } catch (e) {
    debugLog(`ERROR ${url}`, e.message, true);
    return { ok: false, status: 0, data: { message: e.message } };
  }
}

async function apiFetchJSON(url, method, bodyObj) {
  return apiFetch(url, {
    method: method || "GET",
    headers: { "Content-Type": "application/json" },
    body: bodyObj ? JSON.stringify(bodyObj) : undefined,
  });
}

function formatDepAccountInfo(fields) {
  if (!fields) return null;
  const line1Parts = [];
  const line2Parts = [];

  if (fields.org_name) line1Parts.push(fields.org_name);
  if (fields.server_name) line1Parts.push(`Server: ${fields.server_name}`);

  if (fields.admin_id && fields.facilitator_id && fields.admin_id === fields.facilitator_id) {
    line1Parts.push(`帳號: ${fields.admin_id}`);
  } else {
    if (fields.admin_id) line1Parts.push(`管理者: ${fields.admin_id}`);
    if (fields.facilitator_id) line1Parts.push(`Facilitator: ${fields.facilitator_id}`);
  }

  if (fields.org_id) line2Parts.push(`組織代碼: ${fields.org_id}`);
  if (fields.server_uuid) line2Parts.push(`UUID: ${fields.server_uuid}`);

  return {
    line1: line1Parts.join("  ・  "),
    line2: line2Parts.join("  ・  "),
  };
}

// ---- 頂部 dep-account-detail ----
async function loadDepAccountDetail() {
  const line1El = document.getElementById("dep-info-line1-text");
  const line2El = document.getElementById("dep-info-line2");
  const lightEl = document.getElementById("dep-status-light");
  if (!line1El) return;

  line1El.textContent = "載入中...";
  line2El.textContent = "";
  lightEl.className = "status-light";

  const res = await apiFetch("/api/dep-account-detail");
  const success = res.ok && res.data && res.data.returncode === 0 && res.data.fields;

  lightEl.className = "status-light " + (success ? "ok" : "error");

  if (success) {
    const formatted = formatDepAccountInfo(res.data.fields);
    line1El.textContent = formatted.line1 || "(無資料)";
    line2El.textContent = formatted.line2 || "";
  } else {
    const out = (res.data && (res.data.stdout || res.data.stderr || "").trim()) || "";
    line1El.textContent = out || "無法取得 ASM 帳號資訊";
    line2El.textContent = "";
  }
}

// ---- Modal 共用 ----
function openModal(id) {
  document.getElementById(id).classList.remove("hidden");
}
function closeModal(id) {
  document.getElementById(id).classList.add("hidden");
}

// ---------------------------------------------------------------------------
// 共用表格排序工具,給[裝置與命令]、[裝置註冊狀態]、[系統紀錄]這幾個頁面的資料表格共用。
// ---------------------------------------------------------------------------
/**
 * 建立一個表格排序控制器。
 * initialKey/initialDir: 預設排序欄位與方向(選填,不給的話預設不排序)
 * 回傳: { state, sortRows(rows, columns), sortArrow(key), handleHeaderClick(key) }
 *
 * columns裡每個欄位可以指定type: "text"(預設,字串排序,支援中文)、
 * "number"(數值排序,空值視為最小)、"bool"(布林值排序,false排在true前面)
 */
function createTableSorter(initialKey, initialDir) {
  const state = { key: initialKey || null, dir: initialDir || "asc" };

  function sortRows(rows, columns) {
    if (!state.key) return rows;
    const colSpec = (columns || []).find((c) => c.key === state.key) || {};
    const type = colSpec.type || "text";
    const sorted = [...rows].sort((a, b) => {
      let av = a[state.key];
      let bv = b[state.key];
      let cmp;
      if (type === "number") {
        const an = (av === null || av === undefined || av === "") ? -Infinity : Number(av);
        const bn = (bv === null || bv === undefined || bv === "") ? -Infinity : Number(bv);
        cmp = an - bn;
      } else if (type === "bool") {
        const ab = !!av, bb = !!bv;
        cmp = (ab === bb) ? 0 : (ab ? 1 : -1);
      } else {
        cmp = String(av ?? "").localeCompare(String(bv ?? ""), "zh-Hant");
      }
      return state.dir === "asc" ? cmp : -cmp;
    });
    return sorted;
  }

  function sortArrow(key) {
    if (state.key !== key) return "";
    return state.dir === "asc" ? " ▲" : " ▼";
  }

  function handleHeaderClick(key) {
    if (state.key === key) {
      state.dir = state.dir === "asc" ? "desc" : "asc";
    } else {
      state.key = key;
      state.dir = "asc";
    }
  }

  return { state, sortRows, sortArrow, handleHeaderClick };
}

document.addEventListener("DOMContentLoaded", () => {
  initDebugPanel();
  loadDepAccountDetail();

  document.addEventListener("change", (e) => {
    if (!e.target.classList.contains("image-upload-picker")) return;
    const file = e.target.files[0];
    if (!file) return;

    const fieldName = e.target.dataset.targetField;
    const wrapper = e.target.closest("div").parentElement; // 外層的field容器,包含隱藏欄位跟預覽區
    const hiddenInput = wrapper.querySelector(`input[type="hidden"][data-field="${fieldName}"]`);
    const previewContainer = wrapper.querySelector(".image-upload-preview");

    const reader = new FileReader();
    reader.onload = () => {
      // readAsDataURL的結果格式是"data:image/png;base64,XXXX",只需要取base64部分,
      // 逗號後面才是真正的內容
      const base64Content = reader.result.split(",")[1];
      hiddenInput.value = base64Content;
      previewContainer.innerHTML = `<img src="${reader.result}" style="width:100%; height:100%; object-fit:cover;">`;
    };
    reader.readAsDataURL(file);
  });

  document.addEventListener("click", (e) => {
    if (!e.target.classList.contains("image-upload-clear-btn")) return;
    const fieldName = e.target.dataset.targetField;
    const wrapper = e.target.closest("div").parentElement;
    const hiddenInput = wrapper.querySelector(`input[type="hidden"][data-field="${fieldName}"]`);
    const previewContainer = wrapper.querySelector(".image-upload-preview");
    hiddenInput.value = "";
    previewContainer.innerHTML = `<span style="font-size:11px; color:#9ca3af;">無圖示</span>`;
  });
});
