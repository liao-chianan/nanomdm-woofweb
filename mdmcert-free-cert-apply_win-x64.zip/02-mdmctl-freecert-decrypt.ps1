﻿# 設定執行路徑為腳本所在的資料夾
Set-Location -Path $PSScriptRoot

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  mdmcert.download 郵件附件解密工具" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan

# 0. 確保 mdm-certificates 資料夾存在 (若無則自動建立)
$certDir = ".\mdm-certificates"
if (-not (Test-Path -Path $certDir)) {
    New-Item -ItemType Directory -Force -Path $certDir | Out-Null
    Write-Host "📁 已自動建立 $certDir 資料夾" -ForegroundColor Gray
}

# 1. 檢查 mdmctl.exe 是否存在
if (-not (Test-Path ".\mdmctl.exe")) {
    Write-Host "❌ 找不到 mdmctl.exe，請確認本腳本與 mdmctl.exe 位於同一資料夾！" -ForegroundColor Red
    Read-Host "請按 Enter 鍵結束..."
    exit
}

# 2. 自動搜尋資料夾下的 .p7 檔案 (依修改時間排序，最新在最前)
$p7Files = Get-ChildItem -Path ".\" -Filter "*.p7" | Sort-Object LastWriteTime -Descending

$selectedFile = ""

if ($p7Files.Count -eq 1) {
    # 情況 A：只找到 1 個 .p7 檔案
    $autoFile = $p7Files[0].Name
    Write-Host "🔍 偵測到郵件附件檔案：$autoFile" -ForegroundColor Yellow
    $confirm = Read-Host "是否直接使用此檔案進行解密？(Y/n)"
    if ([string]::IsNullOrWhiteSpace($confirm) -or $confirm -match "^[Yy]$") {
        $selectedFile = $p7Files[0].FullName
    }
} elseif ($p7Files.Count -gt 1) {
    # 情況 B：找到多個 .p7 檔案，顯示選單供使用者選擇
    Write-Host "🔍 偵測到多個 .p7 附件，請選擇要解密的檔案：" -ForegroundColor Yellow
    for ($i = 0; $i -lt $p7Files.Count; $i++) {
        Write-Host " [$($i+1)] $($p7Files[$i].Name) ($($p7Files[$i].LastWriteTime.ToString('yyyy-MM-dd HH:mm')))" -ForegroundColor Green
    }
    
    do {
        $selection = Read-Host "請輸入選項號碼 (1-$($p7Files.Count))"
        if ($selection -match "^\d+$" -and [int]$selection -ge 1 -and [int]$selection -le $p7Files.Count) {
            $selectedFile = $p7Files[[int]$selection - 1].FullName
            break
        } else {
            Write-Host "❌ 無效的選項，請重新輸入！" -ForegroundColor Red
        }
    } while ($true)
}

# 情況 C：沒有偵測到檔案，或使用者選擇手動輸入
if ([string]::IsNullOrWhiteSpace($selectedFile)) {
    do {
        $inputPath = Read-Host "請輸入檔名，或直接將 .p7 檔案【拖曳】至此視窗"
        
        # 清除因拖曳檔案產生的前後引號
        $cleanPath = $inputPath.Trim('"').Trim("'")

        if (Test-Path -Path $cleanPath) {
            $selectedFile = $cleanPath
            break
        } else {
            Write-Host "❌ 找不到檔案 '$cleanPath'，請確認檔名或路徑正確！" -ForegroundColor Red
        }
    } while ($true)
}

# 3. 執行 mdmctl 解密指令
$fileNameOnly = Split-Path $selectedFile -Leaf
Write-Host "`n🚀 正在解密檔案: $fileNameOnly ..." -ForegroundColor Green

./mdmctl.exe mdmcert.download -decrypt="$selectedFile"

# 4. 檢查執行結果與後續指引
if ($LASTEXITCODE -eq 0) {
    Write-Host "`n==========================================" -ForegroundColor Cyan
    Write-Host "🎉 解密成功！" -ForegroundColor Green
    Write-Host "產出檔案：mdm-certificates\mdmcert.download.push.req" -ForegroundColor Yellow
    Write-Host "==========================================" -ForegroundColor Cyan
    
    Write-Host "`n📌 接下來的後續步驟：" -ForegroundColor White
    Write-Host "1. 前往 Apple Push Portal 網站：" -ForegroundColor Gray
    Write-Host "   👉 https://identity.apple.com/pushcert" -ForegroundColor Cyan
    Write-Host "2. 使用學校/機構專用的 Apple ID 登入。" -ForegroundColor Gray
    Write-Host "3. 點擊 'Create a Certificate' (或選擇原本的憑證點擊 'Renew')。" -ForegroundColor Gray
    Write-Host "4. 上傳剛產出的檔案：" -ForegroundColor Gray
    Write-Host "   📄 mdm-certificates\mdmcert.download.push.req" -ForegroundColor Yellow
    Write-Host "   (提示：若選檔時看不到檔案，請切換選單為 '所有檔案 (*.*)')" -ForegroundColor DarkGray
    Write-Host "5. 下載 Apple 簽發的 APNs 憑證 (.pem 或 .cer 格式)。" -ForegroundColor Gray
    Write-Host "6. 匯入 MDM 時，將下載的憑證與下列私鑰搭配使用：" -ForegroundColor Gray
    Write-Host "   🔑 私鑰：mdmcert.download.push.key`n" -ForegroundColor Yellow
    Write-Host "   🔑 憑證：xxxxx.pem 或 xxxxx.cer`n" -ForegroundColor Yellow
    Write-Host "!!重要 請務必保留本資料夾中的相關憑證與私鑰!!!!`n" -ForegroundColor Red


} else {
    Write-Host "`n❌ 解密失敗，請檢查檔案是否完整或嘗試重新下載信件附件。" -ForegroundColor Red
}

Read-Host "請按 Enter 鍵結束..."