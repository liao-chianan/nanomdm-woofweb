﻿# 設定執行路徑為腳本所在的資料夾
Set-Location -Path $PSScriptRoot

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  mdmcert.download CSR 請求發起工具" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan

# 1. 建立離線設定檔
$configDir = "$env:USERPROFILE\.micromdm"
if (-not (Test-Path -Path $configDir)) {
    New-Item -ItemType Directory -Force -Path $configDir | Out-Null
}
Set-Content -Path "$configDir\servers.json" -Value "{}" -Encoding UTF8

# 2. 檢查 mdmctl.exe 是否存在
if (-not (Test-Path ".\mdmctl.exe")) {
    Write-Host "❌ 找不到 mdmctl.exe，請確認本腳本與 mdmctl.exe 位於同一資料夾！" -ForegroundColor Red
    Read-Host "請按 Enter 鍵結束..."
    exit
}

# 3. 互動式提示使用者輸入 Email (若輸入空白會提示重輸入)
do {
    $email = Read-Host "請輸入您在 mdmcert.download 註冊並驗證通過的 Email"
    if ([string]::IsNullOrWhiteSpace($email)) {
        Write-Host "❌ Email 不能為空，請重新輸入！" -ForegroundColor Red
    }
} while ([string]::IsNullOrWhiteSpace($email))

Write-Host "`n🚀 正在使用 Email: $email 發起 mdmcert.download 請求..." -ForegroundColor Green

# 4. 帶入變數執行 mdmctl
./mdmctl.exe mdmcert.download -new -email="$email"

# 5. 檢查執行結果與顯示後續指引
if ($LASTEXITCODE -eq 0) {
    Write-Host "`n==========================================" -ForegroundColor Cyan
    Write-Host "🎉 請求發送成功！" -ForegroundColor Green
    Write-Host "已在 'mdm-certificates' 資料夾內生成私鑰檔：" -ForegroundColor Gray
    Write-Host "🔑 mdm-certificates\mdmcert.download.push.key" -ForegroundColor Yellow
    Write-Host "==========================================" -ForegroundColor Cyan
    
    Write-Host "`n📌 接下來的後續步驟：" -ForegroundColor White
    Write-Host "1. 前往學校電子信箱 ($email) 收信。" -ForegroundColor Gray
    Write-Host "2. 找到 mdmcert.download 寄發的郵件，並【下載 .p7 格式附件檔】。" -ForegroundColor Gray
    Write-Host "   (附件檔名範例：mdm_signed_request.xxxx.plist.b64.p7)" -ForegroundColor DarkGray
    Write-Host "3. 將下載的附件檔放在與本腳本【相同的資料夾】內。" -ForegroundColor Gray
    Write-Host "4. 執行 02-mdmctl-freecert-decrypt 進行解密作業。`n" -ForegroundColor Yellow
    Write-Host "5. 重要!請務必保留本資料夾所有檔案!!!。`n" -ForegroundColor Red
} else {
    Write-Host "`n❌ 請求發送失敗！" -ForegroundColor Red
    Write-Host "請確認：" -ForegroundColor Red
    Write-Host "  1. $email 是否已在 https://mdmcert.download 完成點擊驗證信。" -ForegroundColor Red
    Write-Host "  2. 本機網路連線是否正常。`n" -ForegroundColor Red
}

Read-Host "請按 Enter 鍵結束..."